Устанавливаем hdr
1) копируем VK_hdr_layer в /home/safe/VK_hdr_layer
2) открываем build.sh


файл fix-wayland-scanner.patch скореесь не нужен


3) в консоль вставить
#!/usr/bin/env bash
unset DISPLAY
export DXVK_HDR=1
export ENABLE_HDR_WSI=1
export VKD3D_CONFIG=dxr11
