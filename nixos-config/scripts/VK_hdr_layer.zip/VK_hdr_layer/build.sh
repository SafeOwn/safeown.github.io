#!/usr/bin/env bash
set -e

if [[ ! -f shell.nix ]]; then
    echo "❌ shell.nix не найден!"
    exit 1
fi

echo "🧹 Очищаем старую сборку..."
rm -rf builddir

echo "📦 Запускаем nix-shell и собираем..."
nix-shell --run "
    meson setup builddir --prefix=\$HOME/.local &&
    ninja -C builddir &&
    meson install -C builddir &&
    echo '✅ Сборка завершена. Слой установлен в ~/.local'
"

echo "📌 Не забудьте добавить в ~/.bashrc:"
echo "export VK_LAYER_PATH=\"\$HOME/.local/share/vulkan/explicit_layer.d\""
